<?php
require "db.php";
if (isset($_POST['log'])) {
	$errors = array();
	$user = R::FindOne('users', 'email = ?', array($_POST['email']));
	if ( $user ) {
		if (password_verify($_POST['pass'], $user->password)) {
			$_SESSION['logged_user'] = $user;

	} else {
		$errors[] = 'Неправильний пароль!';
	}
	} else {
		$errors[] = 'Користувач з таким Email не знайдено!';
	}  

if (!empty($errors))
{
	echo '<div style="color:red;">'.array_shift($errors).'</div>';
}
}
?>


<?php if(isset($_SESSION['logged_user'])) :?>
	<div class="index" align="center">
Hi, <?php echo $_SESSION['logged_user']->first_name; ?><hr>
<title>Annotell Project</title>
<a href="start_pt.php"><input type="button" name="start_pt" value="Почати завдання"></a><br><br>
<a href="end_pt.php"><input type="button" name="end_pt" value="Закінчити завдання"></a>
<hr>
<a href="logout.php"><input type="button" name="logout" value="Вихід"></a>
</div>
<?php else : ?>
<!DOCTYPE html>
<html>
<head>
<title>Annotell Project</title>
<link rel="stylesheet" href="st.css" type="text/css">
</head>
<body>
	<br><br><br><br><br><br><br>
<p align="center"><font size="20" face="Calibri">Welcome to Annotell Project!</font></p>
<div class="centered" align="center">
<form method="POST">
	<br>
<font size="5">Email:</font><br>
<input type="email" name="email"><br>
<font size="5">Пароль:</font><br>
<input type="password" name="pass" size="40" height="20"><br>
<input type="submit" name="log" value="Увійти"><br>
Ще немає аккаунту? <a href="/reg.php">Зареєструватись!</a>
</form>
</div>
</body>
</html>
<?php endif; ?>