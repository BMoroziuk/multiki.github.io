<?php
require "db.php";
if (isset($_POST['reg'])){
	if ($_POST['password']!= $_POST['password2']){
		$errors[] = "Паролі не співпадають!";
	}
	if (empty($errors)) {
	$users = R::dispense('users');
	$users->email = $_POST['email'];
	$users->first_name = $_POST['first_name'];
	$users->last_name = $_POST['last_name'];
	$users->password = password_hash($_POST['password'], PASSWORD_DEFAULT);
	R::store($users);
	header("Location: /");
}
}
?>




<!DOCTYPE html>
<html>
<head>
	<title>Annotell Project - Реєстрація</title>
</head>
<body>
<form method="POST">
<input type="email" name="email" placeholder="Email"><br>
<input type="first_name" name="first_name" placeholder="Ім'я"><br>
<input type="last_name" name="last_name" placeholder="Прізвище"><br>
<input type="password" name="password" placeholder="Пароль"><br>
<input type="password" name="password2" placeholder="Пароль ще раз"><br><br>
<input type="submit" name="reg">
</form>
<?php if(!empty($errors)) echo '<div style="color:red;">'.array_shift($errors).'</div>'; ?>
</body>
</html>