<?php
require "rb.php";
R::setup('mysql:host=localhost;dbname=annotell','root','');
$connect = mysqli_connect('localhost','root','','annotell');
session_start();
?>