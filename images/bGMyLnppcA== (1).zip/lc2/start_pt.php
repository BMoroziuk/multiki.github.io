<?php
require "db.php";
$time_start = date("Y-m-d H:i:s");
if (isset($_POST['do_add_task']))
{
	$errors = array();
 	if( trim($_POST['tasks']) == '')
	{
      $errors[] = 'Введіть назву завдання!';
	} 

	if( trim($_POST['type_tasks']) == 'Не вибрано')
	{
      $errors[] = 'Виберіть тип завдання!';
	} 

	if(empty($errors))
	{
		$count = R::dispense('count');
		$count->email = $_SESSION['logged_user']->email;
		$count->tasks = $_POST['tasks'];
		$count->type_tasks = $_POST['type_tasks'];
		$count->time = $_SESSION['logged_user']->$time_start= date("Y-m-d H:i:s");
		R::store($count);
		header("Location: /");
	} else
	{
		echo '<div style="color: red;">'.array_shift($errors).'</div><hr>';
	}

}
?>

<form method="POST">
	
	<p>
    	<strog>Назва завдання (скопіюйте повну назву завдання, яке ви будете виконувати):</strog>
    	<input type="tasks" name="tasks">
	</p>

	<p>
    	<strog>Виберіть тип:</strog>
    	<select name="type_tasks">
        <option>Не вибрано</option>
    	<option>Annotate</option>
    	<option>Correct</option>
    	</select>
	</p>

	
	<p>
    	<button type="submit" name="do_add_task">Розпочати!</button>
	</p>
</form>

