<?php
require "db.php";
$time_end = date("Y-m-d H:i:s");
if (isset($_POST['do_add_task']))
{
	$errors = array();
 	if( trim($_POST['tasks']) == 'Не вибрано')
	{
      $errors[] = 'Виберіть завдання!';
	} 

	if( trim($_POST['type_tasks']) == 'Не вибрано')
	{
      $errors[] = 'Виберіть тип завдання!';
	} 

	if(empty($errors))
	{
		$product = R::dispense('product');
		$product->email = $_SESSION['logged_user']->email;
		$product->tasks = $_POST['tasks'];
		$product->type_tasks = $_POST['type_tasks'];
        $product->picture = $_POST['picture'];
        $product->pt = $_POST['pt'];
		$product->time = $_SESSION['logged_user']->$time_end = date("Y-m-d H:i:s");
		R::store($product);
		header("Location: /");
	} else
	{
		echo '<div style="color: red;">'.array_shift($errors).'</div><hr>';
	}

}
?>

<form method="POST">

	<p>
    	<strog>Назва завдання (скопіюйте повну назву завдання, яке ви виконували):</strog>
    	<input type="tasks" name="tasks">
	</p>

	<p>
    	<strog>Виберіть тип:</strog>
    	<select name="type_tasks">
        <option>Не вибрано</option>
    	<option>Annotate</option>
    	<option>Correct</option>
    	</select>
	</p>
	
	К-сть картинок: <input type="picture" name="picture"><br><br>
	PT (Значення PT обов'язково писати через ,): <input type="pt" name="pt">
	
	<p>
    	<button type="submit" name="do_add_task">Закінчити!</button>
	</p>
</form>
